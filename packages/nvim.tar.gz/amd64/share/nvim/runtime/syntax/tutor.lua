vim.cmd [[
syntax match tutorExpect /^--->.*$/
]]
